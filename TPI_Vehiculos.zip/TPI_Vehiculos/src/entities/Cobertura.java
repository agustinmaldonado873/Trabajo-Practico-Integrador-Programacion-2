package entities;

public enum Cobertura {
    RC,
    TERCEROS,
    TODO_RIESGO
}
