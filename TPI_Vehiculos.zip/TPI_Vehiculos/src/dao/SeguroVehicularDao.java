package dao;

import entities.SeguroVehicular;

public interface SeguroVehicularDao extends GenericDao<SeguroVehicular> {
    // Más adelante podemos sumar métodos específicos si los necesitamos
}
