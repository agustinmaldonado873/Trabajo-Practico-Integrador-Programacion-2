package dao;

import config.DatabaseConnection;
import entities.Cobertura;
import entities.SeguroVehicular;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SeguroVehicularDaoImpl implements SeguroVehicularDao {

    private static final String INSERT_SQL =
            "INSERT INTO seguro_vehicular (eliminado, aseguradora, nro_poliza, cobertura, vencimiento, vehiculo_id) " +
            "VALUES (?, ?, ?, ?, ?, NULL)";

    private static final String SELECT_BY_ID_SQL =
            "SELECT id, eliminado, aseguradora, nro_poliza, cobertura, vencimiento " +
            "FROM seguro_vehicular WHERE id = ? AND eliminado = FALSE";

    private static final String SELECT_ALL_SQL =
            "SELECT id, eliminado, aseguradora, nro_poliza, cobertura, vencimiento " +
            "FROM seguro_vehicular WHERE eliminado = FALSE";

    private static final String UPDATE_SQL =
            "UPDATE seguro_vehicular SET eliminado = ?, aseguradora = ?, nro_poliza = ?, " +
            "cobertura = ?, vencimiento = ? WHERE id = ?";

    // baja logica
    private static final String DELETE_SQL =
            "UPDATE seguro_vehicular SET eliminado = TRUE WHERE id = ?";

    // =============================
    // Metodos con conexion interna
    // =============================

    @Override
    public SeguroVehicular crear(SeguroVehicular entidad) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return crear(entidad, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public SeguroVehicular leer(long id) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return leer(id, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public List<SeguroVehicular> leerTodos() throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return leerTodos(conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void actualizar(SeguroVehicular entidad) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            actualizar(entidad, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void eliminar(long id) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            eliminar(id, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    // =============================
    // Metodos con conexion externa
    // =============================

    @Override
    public SeguroVehicular crear(SeguroVehicular entidad, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            ps.setBoolean(1, entidad.getEliminado() != null ? entidad.getEliminado() : false);
            ps.setString(2, entidad.getAseguradora());
            ps.setString(3, entidad.getNroPoliza());
            ps.setString(4, entidad.getCobertura().name());
            ps.setDate(5, Date.valueOf(entidad.getVencimiento()));

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    long idGenerado = rs.getLong(1);
                    entidad.setId(idGenerado);
                }
            }
        }
        return entidad;
    }

    @Override
    public SeguroVehicular leer(long id, Connection conn) throws SQLException {
        SeguroVehicular seguro = null;

        try (PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {
            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    seguro = mapearSeguro(rs);
                }
            }
        }

        return seguro;
    }

    @Override
    public List<SeguroVehicular> leerTodos(Connection conn) throws SQLException {
        List<SeguroVehicular> lista = new ArrayList<>();

        try (PreparedStatement ps = conn.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SeguroVehicular s = mapearSeguro(rs);
                lista.add(s);
            }
        }

        return lista;
    }

    @Override
    public void actualizar(SeguroVehicular entidad, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setBoolean(1, entidad.getEliminado() != null ? entidad.getEliminado() : false);
            ps.setString(2, entidad.getAseguradora());
            ps.setString(3, entidad.getNroPoliza());
            ps.setString(4, entidad.getCobertura().name());
            ps.setDate(5, Date.valueOf(entidad.getVencimiento()));
            ps.setLong(6, entidad.getId());

            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(long id, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {
            ps.setLong(1, id);
            ps.executeUpdate();
        }
    }

    // =============================
    // Mapear ResultSet -> SeguroVehicular
    // =============================

    private SeguroVehicular mapearSeguro(ResultSet rs) throws SQLException {
        SeguroVehicular s = new SeguroVehicular();

        s.setId(rs.getLong("id"));
        s.setEliminado(rs.getBoolean("eliminado"));
        s.setAseguradora(rs.getString("aseguradora"));
        s.setNroPoliza(rs.getString("nro_poliza"));

        String coberturaStr = rs.getString("cobertura");
        if (coberturaStr != null) {
            s.setCobertura(Cobertura.valueOf(coberturaStr));
        }

        Date fecha = rs.getDate("vencimiento");
        if (fecha != null) {
            LocalDate fechaLocal = fecha.toLocalDate();
            s.setVencimiento(fechaLocal);
        }

        return s;
    }
}
