package dao;

import config.DatabaseConnection;
import entities.Vehiculo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehiculoDaoImpl implements VehiculoDao {

    private static final String INSERT_SQL =
            "INSERT INTO vehiculo (eliminado, dominio, marca, modelo, anio, nro_chasis) " +
            "VALUES (?, ?, ?, ?, ?, ?)";

    private static final String SELECT_BY_ID_SQL =
            "SELECT id, eliminado, dominio, marca, modelo, anio, nro_chasis " +
            "FROM vehiculo WHERE id = ? AND eliminado = FALSE";

    private static final String SELECT_ALL_SQL =
            "SELECT id, eliminado, dominio, marca, modelo, anio, nro_chasis " +
            "FROM vehiculo WHERE eliminado = FALSE";

    private static final String UPDATE_SQL =
            "UPDATE vehiculo SET eliminado = ?, dominio = ?, marca = ?, modelo = ?, " +
            "anio = ?, nro_chasis = ? WHERE id = ?";

    // baja logica
    private static final String DELETE_SQL =
            "UPDATE vehiculo SET eliminado = TRUE WHERE id = ?";

    // =============================
    // Metodos usando conexion interna
    // =============================

    @Override
    public Vehiculo crear(Vehiculo entidad) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return crear(entidad, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public Vehiculo leer(long id) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return leer(id, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public List<Vehiculo> leerTodos() throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return leerTodos(conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void actualizar(Vehiculo entidad) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            actualizar(entidad, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void eliminar(long id) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            eliminar(id, conn);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    // =============================
    // Metodos usando conexion externa
    // =============================

    @Override
    public Vehiculo crear(Vehiculo entidad, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            ps.setBoolean(1, entidad.getEliminado() != null ? entidad.getEliminado() : false);
            ps.setString(2, entidad.getDominio());
            ps.setString(3, entidad.getMarca());
            ps.setString(4, entidad.getModelo());

            if (entidad.getAnio() != null) {
                ps.setInt(5, entidad.getAnio());
            } else {
                ps.setNull(5, Types.INTEGER);
            }

            ps.setString(6, entidad.getNroChasis());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    long idGenerado = rs.getLong(1);
                    entidad.setId(idGenerado);
                }
            }
        }
        return entidad;
    }

    @Override
    public Vehiculo leer(long id, Connection conn) throws SQLException {
        Vehiculo vehiculo = null;

        try (PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {
            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    vehiculo = mapearVehiculo(rs);
                }
            }
        }

        return vehiculo;
    }

    @Override
    public List<Vehiculo> leerTodos(Connection conn) throws SQLException {
        List<Vehiculo> lista = new ArrayList<>();

        try (PreparedStatement ps = conn.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Vehiculo v = mapearVehiculo(rs);
                lista.add(v);
            }
        }

        return lista;
    }

    @Override
    public void actualizar(Vehiculo entidad, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setBoolean(1, entidad.getEliminado() != null ? entidad.getEliminado() : false);
            ps.setString(2, entidad.getDominio());
            ps.setString(3, entidad.getMarca());
            ps.setString(4, entidad.getModelo());

            if (entidad.getAnio() != null) {
                ps.setInt(5, entidad.getAnio());
            } else {
                ps.setNull(5, Types.INTEGER);
            }

            ps.setString(6, entidad.getNroChasis());
            ps.setLong(7, entidad.getId());

            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(long id, Connection conn) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {
            ps.setLong(1, id);
            ps.executeUpdate();
        }
    }

    // =============================
    // Metodo auxiliar para mapear ResultSet -> Vehiculo
    // =============================

    private Vehiculo mapearVehiculo(ResultSet rs) throws SQLException {
        Vehiculo v = new Vehiculo();
        v.setId(rs.getLong("id"));
        v.setEliminado(rs.getBoolean("eliminado"));
        v.setDominio(rs.getString("dominio"));
        v.setMarca(rs.getString("marca"));
        v.setModelo(rs.getString("modelo"));

        int anio = rs.getInt("anio");
        if (!rs.wasNull()) {
            v.setAnio(anio);
        }

        v.setNroChasis(rs.getString("nro_chasis"));

        // por ahora no cargamos el seguro; eso se hara desde el Service
        v.setSeguro(null);

        return v;
    }
}
