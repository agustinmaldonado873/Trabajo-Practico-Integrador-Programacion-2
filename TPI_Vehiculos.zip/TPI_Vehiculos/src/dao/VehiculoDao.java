package dao;

import entities.Vehiculo;

public interface VehiculoDao extends GenericDao<Vehiculo> {
    // acá después podemos agregar búsquedas específicas, por ejemplo:
    // Vehiculo buscarPorDominio(String dominio) throws SQLException;
}
