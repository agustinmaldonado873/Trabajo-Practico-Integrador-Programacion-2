package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

// DAO generico pedido en la consigna
public interface GenericDao<T> {

    // Usando una Connection interna (el DAO abre/cierra)
    T crear(T entidad) throws SQLException;

    T leer(long id) throws SQLException;

    List<T> leerTodos() throws SQLException;

    void actualizar(T entidad) throws SQLException;

    void eliminar(long id) throws SQLException;

    // Versión usando una Connection externa (para transacciones en Service)
    T crear(T entidad, Connection conn) throws SQLException;

    T leer(long id, Connection conn) throws SQLException;

    List<T> leerTodos(Connection conn) throws SQLException;

    void actualizar(T entidad, Connection conn) throws SQLException;

    void eliminar(long id, Connection conn) throws SQLException;
}
