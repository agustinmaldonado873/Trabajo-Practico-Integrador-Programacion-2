package menu;

import entities.Vehiculo;
import entities.SeguroVehicular;
import entities.Cobertura;

import service.VehiculoServiceImpl;
import service.SeguroVehicularServiceImpl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class MenuPrincipal {

    private static final Scanner scanner = new Scanner(System.in);
    private static final VehiculoServiceImpl vehiculoService = new VehiculoServiceImpl();
    private static final SeguroVehicularServiceImpl seguroService = new SeguroVehicularServiceImpl();

    public static void main(String[] args) {

        int opcion;

        do {
            System.out.println("================================");
            System.out.println("      MENU PRINCIPAL");
            System.out.println("================================");
            System.out.println("1. Crear vehiculo");
            System.out.println("2. Listar vehiculos");
            System.out.println("3. Buscar vehiculo por ID");
            System.out.println("4. Eliminar vehiculo");
            System.out.println("5. Crear seguro vehicular");
            System.out.println("6. Listar seguros");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 -> crearVehiculo();
                case 2 -> listarVehiculos();
                case 3 -> buscarVehiculoPorId();
                case 4 -> eliminarVehiculo();
                case 5 -> crearSeguro();
                case 6 -> listarSeguros();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);
    }

    // =========================================================
    //  VEHICULOS
    // =========================================================

    private static void crearVehiculo() {
        try {
            scanner.nextLine(); // limpiar buffer

            Vehiculo v = new Vehiculo();

            System.out.print("Dominio: ");
            v.setDominio(scanner.nextLine());

            System.out.print("Marca: ");
            v.setMarca(scanner.nextLine());

            System.out.print("Modelo: ");
            v.setModelo(scanner.nextLine());

            System.out.print("Anio: ");
            v.setAnio(leerEntero());

            System.out.print("Nro de chasis: ");
            scanner.nextLine(); // limpiar resto
            v.setNroChasis(scanner.nextLine());

            Vehiculo creado = vehiculoService.crear(v);
            System.out.println("Vehiculo creado con exito: " + creado);

        } catch (Exception e) {
            System.out.println("Error al crear vehiculo: " + e.getMessage());
        }
    }

    private static void listarVehiculos() {
        try {
            List<Vehiculo> lista = vehiculoService.leerTodos();
            if (lista.isEmpty()) {
                System.out.println("No hay vehiculos cargados.");
            } else {
                for (Vehiculo v : lista) {
                    System.out.println(v);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al listar vehiculos: " + e.getMessage());
        }
    }

    private static void buscarVehiculoPorId() {
        try {
            System.out.print("ID del vehiculo: ");
            long id = leerLong();

            Vehiculo v = vehiculoService.leer(id);
            if (v != null) {
                System.out.println(v);
            } else {
                System.out.println("No se encontro vehiculo con ese ID.");
            }
        } catch (Exception e) {
            System.out.println("Error al buscar vehiculo: " + e.getMessage());
        }
    }

    private static void eliminarVehiculo() {
        try {
            System.out.print("ID del vehiculo a eliminar: ");
            long id = leerLong();

            vehiculoService.eliminar(id);
            System.out.println("Vehiculo eliminado (borrado logico).");
        } catch (Exception e) {
            System.out.println("Error al eliminar vehiculo: " + e.getMessage());
        }
    }

    // =========================================================
    //  SEGUROS
    // =========================================================

    private static void crearSeguro() {
        try {
            scanner.nextLine(); // limpiar buffer

            SeguroVehicular s = new SeguroVehicular();

            System.out.print("Nombre de la aseguradora: ");
            s.setAseguradora(scanner.nextLine());

            System.out.print("Numero de poliza: ");
            s.setNroPoliza(scanner.nextLine());

            System.out.println("Cobertura:");
            System.out.println("1 - RC");
            System.out.println("2 - TERCEROS");
            System.out.println("3 - TODO_RIESGO");
            System.out.print("Elija una opcion: ");
            int opCob = leerEntero();

            switch (opCob) {
                case 1 -> s.setCobertura(Cobertura.RC);
                case 2 -> s.setCobertura(Cobertura.TERCEROS);
                case 3 -> s.setCobertura(Cobertura.TODO_RIESGO);
                default -> {
                    System.out.println("Opcion invalida. Se usara RC por defecto.");
                    s.setCobertura(Cobertura.RC);
                }
            }

            // vencimiento: hoy + 1 anio
            LocalDate venc = LocalDate.now().plusYears(1);
            s.setVencimiento(venc);

            SeguroVehicular creado = seguroService.crear(s);
            System.out.println("Seguro creado con exito: " + creado);

        } catch (Exception e) {
            System.out.println("Error al crear seguro: " + e.getMessage());
        }
    }

    private static void listarSeguros() {
        try {
            List<SeguroVehicular> lista = seguroService.leerTodos();
            if (lista.isEmpty()) {
                System.out.println("No hay seguros cargados.");
            } else {
                for (SeguroVehicular s : lista) {
                    System.out.println(s);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al listar seguros: " + e.getMessage());
        }
    }

    // =========================================================
    //  METODOS AUXILIARES
    // =========================================================

    private static int leerEntero() {
        while (true) {
            try {
                String linea = scanner.nextLine();
                return Integer.parseInt(linea.trim());
            } catch (NumberFormatException e) {
                System.out.print("Ingrese un numero entero valido: ");
            }
        }
    }

    private static long leerLong() {
        while (true) {
            try {
                String linea = scanner.nextLine();
                return Long.parseLong(linea.trim());
            } catch (NumberFormatException e) {
                System.out.print("Ingrese un numero valido: ");
            }
        }
    }
}
