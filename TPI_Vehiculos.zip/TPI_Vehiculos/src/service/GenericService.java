package service;

import java.util.List;

public interface GenericService<T> {

    T crear(T entidad) throws Exception;

    T leer(long id) throws Exception;

    List<T> leerTodos() throws Exception;

    void actualizar(T entidad) throws Exception;

    void eliminar(long id) throws Exception;
}
