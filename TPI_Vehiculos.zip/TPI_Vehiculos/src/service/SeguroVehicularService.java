package service;

import entities.SeguroVehicular;

public interface SeguroVehicularService extends GenericService<SeguroVehicular> {
    // aca despues se pueden agregar metodos especificos para seguro
}
