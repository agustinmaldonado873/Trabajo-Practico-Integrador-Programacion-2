package service;

import config.DatabaseConnection;
import dao.VehiculoDao;
import dao.VehiculoDaoImpl;
import entities.Vehiculo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class VehiculoServiceImpl implements VehiculoService {

    private final VehiculoDao vehiculoDao;

    public VehiculoServiceImpl() {
        this.vehiculoDao = new VehiculoDaoImpl();
    }

    @Override
    public Vehiculo crear(Vehiculo entidad) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            Vehiculo creado = vehiculoDao.crear(entidad, conn);

            conn.commit();
            return creado;
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public Vehiculo leer(long id) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return vehiculoDao.leer(id, conn);
        } finally {
            if (conn != null) conn.close();
        }
    }

    @Override
    public List<Vehiculo> leerTodos() throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return vehiculoDao.leerTodos(conn);
        } finally {
            if (conn != null) conn.close();
        }
    }

    @Override
    public void actualizar(Vehiculo entidad) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            vehiculoDao.actualizar(entidad, conn);

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public void eliminar(long id) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            vehiculoDao.eliminar(id, conn);

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
}
