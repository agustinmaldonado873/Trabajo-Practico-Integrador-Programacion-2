package service;

import config.DatabaseConnection;
import dao.SeguroVehicularDao;
import dao.SeguroVehicularDaoImpl;
import entities.SeguroVehicular;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class SeguroVehicularServiceImpl implements SeguroVehicularService {

    private final SeguroVehicularDao seguroDao;

    public SeguroVehicularServiceImpl() {
        this.seguroDao = new SeguroVehicularDaoImpl();
    }

    @Override
    public SeguroVehicular crear(SeguroVehicular entidad) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            SeguroVehicular creado = seguroDao.crear(entidad, conn);

            conn.commit();
            return creado;
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public SeguroVehicular leer(long id) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return seguroDao.leer(id, conn);
        } finally {
            if (conn != null) conn.close();
        }
    }

    @Override
    public List<SeguroVehicular> leerTodos() throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            return seguroDao.leerTodos(conn);
        } finally {
            if (conn != null) conn.close();
        }
    }

    @Override
    public void actualizar(SeguroVehicular entidad) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            seguroDao.actualizar(entidad, conn);

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public void eliminar(long id) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            seguroDao.eliminar(id, conn);

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
}
