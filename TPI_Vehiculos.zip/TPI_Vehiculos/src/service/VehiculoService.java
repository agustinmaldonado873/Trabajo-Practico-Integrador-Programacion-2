package service;

import entities.Vehiculo;

public interface VehiculoService extends GenericService<Vehiculo> {
    // aca despues podemos agregar metodos especificos, por ejemplo:
    // Vehiculo buscarPorDominio(String dominio) throws Exception;
}
