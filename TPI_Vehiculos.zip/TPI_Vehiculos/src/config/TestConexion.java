package config;

import java.sql.Connection;

public class TestConexion {

    public static void main(String[] args) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println("Conexion a la base tpi_vehiculos OK");
            } else {
                System.out.println("No se pudo establecer la conexion");
            }
        } catch (Exception e) {
            System.out.println("Error al conectar con la base de datos");
            e.printStackTrace();
        }
    }
}
